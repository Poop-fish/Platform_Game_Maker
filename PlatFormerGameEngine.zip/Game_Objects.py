import pygame
from Game_Colors import WHITE,RED,BLACK,BLUE,YELLOW,NEON_GREEN,NEON_PINK
class Platform(pygame.sprite.Sprite):
    def __init__(SELF, x, y, width, height):
        super().__init__()
        SELF.image = pygame.Surface((width, height))
        SELF.image.fill(NEON_GREEN)
        SELF.rect = SELF.image.get_rect()
        SELF.rect.x = x
        SELF.rect.y = y

class Coin(pygame.sprite.Sprite):
    def __init__(SELF, x, y):
        super().__init__()
        SELF.image = pygame.Surface((20, 20))
        SELF.image.fill(YELLOW)
        SELF.rect = SELF.image.get_rect()
        SELF.rect.x = x
        SELF.rect.y = y

class Key(pygame.sprite.Sprite):
    def __init__(SELF, x, y):
        super().__init__()
        SELF.image = pygame.Surface((20, 20))
        SELF.image.fill(NEON_PINK)
        SELF.rect = SELF.image.get_rect()
        SELF.rect.x = x
        SELF.rect.y = y

class Door(pygame.sprite.Sprite):
    def __init__(SELF, x, y):
        super().__init__()
        SELF.image = pygame.Surface((40, 60))
        SELF.image.fill(RED)
        SELF.rect = SELF.image.get_rect()
        SELF.rect.x = x
        SELF.rect.y = y