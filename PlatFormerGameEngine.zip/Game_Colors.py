# Colors
WHITE = ("#ffffff")
BLUE = ("#0008ff")
RED = ("#ff0000")
YELLOW = ("#f2ff00")
NEON_GREEN = ("#15ff00")
NEON_PINK = ("#ff00f2")
BLACK = ("#000000")
