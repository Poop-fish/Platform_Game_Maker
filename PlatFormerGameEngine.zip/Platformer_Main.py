import pygame , random , json
from Game_Objects import Coin , Key , Door , Platform
from Game_Colors import WHITE,RED,BLACK,BLUE,YELLOW,NEON_GREEN,NEON_PINK
# \\ Initialize pygame 🚀 \\ 
pygame.init()
# \\ Set screen dimensions 📏 \\ 
SCREEN_WIDTH = 800  # \\ Width of the screen 📏 \\ 
SCREEN_HEIGHT = 600  # \\ Height of the screen 🖥️ \\ 
FPS = 60  # \\ Frames per second ⏱️ \\ 
# \\ Create the screen and set up display 🖼️ \\ 
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("A Game")  # \\ Set the title of the game window 🎮 \\
# --- Classes --- 
class Player(pygame.sprite.Sprite):
    def __init__(SELF):
        super().__init__()
        SELF.image = pygame.Surface((50, 50))  # \\ Create a square image for the player 👾 \\ 
        SELF.image.fill(BLUE)  # \\ Set the player's color 🔵 \\ 
        SELF.rect = SELF.image.get_rect()  # \\ Get the player's rectangular boundaries 📏 \\ 
        SELF.rect.center = (100, SCREEN_HEIGHT - 100)  # \\ Initial player position 🚶 \\ 
        SELF.velocity = 0  # \\ Player's vertical speed 🕹️ \\ 
        SELF.on_ground = False  # \\ Whether the player is on the ground 🏞️ \\ 
        SELF.jump_strength = -15  # \\ How strong the player's jump is 💨 \\ 
        SELF.has_key = False  # \\ Track if player has the key 🔑 \\ 

    def update(SELF, keys, platforms, key, door):
        speed = 5  # \\ Horizontal movement speed ⬅️➡️ \\ 
        if keys[pygame.K_a]:  # \\ Move left ⬅️ \\ 
            SELF.rect.x -= speed
        if keys[pygame.K_d]:  # \\ Move right ➡️ \\ 
            SELF.rect.x += speed
        if keys[pygame.K_SPACE] and SELF.on_ground:  # \\ Jump if on the ground 🦘 \\ 
            SELF.velocity = SELF.jump_strength
        if not SELF.on_ground:  # \\ If not on the ground, gravity pulls down 🌍 \\ 
            SELF.velocity += 1
        SELF.rect.y += SELF.velocity  # \\ Update the vertical position ⬇️ \\ 
        SELF.on_ground = False  # \\ Reset the ground check ⬛ \\ 
        for platform in platforms:  # \\ Check for collisions with platforms 🪶 \\ 
            if SELF.rect.colliderect(platform.rect):  # \\ If player collides with a platform 🟩 \\ 
                if SELF.velocity > 0 and SELF.rect.bottom > platform.rect.top:  # \\ Check if falling 🪂 \\ 
                    SELF.on_ground = True  # \\ Player is on the ground 🏠 \\ 
                    SELF.velocity = 0  # \\ Stop falling 🛑 \\ 
                    SELF.rect.bottom = platform.rect.top  # \\ Position the player on top of the platform 🏔️ \\ 
        if SELF.rect.bottom > SCREEN_HEIGHT:  # \\ If player falls off the screen 📉 \\ 
            SELF.reset_stage()  # \\ Reset the player's position 🔄 \\ 
        if SELF.rect.x < 0:  # \\ Prevent player from moving off the left side ⬅️ \\ 
            SELF.rect.x = 0
        if SELF.rect.x > SCREEN_WIDTH - SELF.rect.width:  # \\ Prevent player from moving off the right side ➡️ \\ 
            SELF.rect.x = SCREEN_WIDTH - SELF.rect.width
        
        # \\ Check if player collides with the key 🔑 \\ 
        if pygame.sprite.collide_rect(SELF, key):
            SELF.has_key = True  # \\ Player gets the key 🗝️ \\ 
            key.kill()  # \\ Remove the key from the screen 💥 \\ 

        # \\ Check if player collides with the door and has the key 🚪\\ 
        if pygame.sprite.collide_rect(SELF, door) and SELF.has_key:
            SELF.transition_to_new_map()  # \\ Transition to the next map 🌍 \\

    def reset_stage(SELF):
        SELF.rect.center = (100, SCREEN_HEIGHT - 100)  # \\ Reset player to start position 🔁 \\ 
        SELF.velocity = 0  # \\ Stop vertical movement 🛑 \\

    def transition_to_new_map(SELF):
        print("Transitioning to a new map... 🌍")  # \\ Print transition message 📝 \\ 
        game.load_next_map()  # \\ Load the next map 🔄 \\

def load_map(filename="TestMap_2.json"):
    platforms = pygame.sprite.Group()  # \\ Group to store all platforms 🪜 \\ 
    coins = pygame.sprite.Group()  # \\ Group to store all coins 💰 \\ 
    door = None  # \\ Initialize door as None 🚪\\ 
    
    try:
        with open(filename, "r") as f:  # \\ Try to load map from file 📂 \\ 
            map_data = json.load(f)  # \\ Read map data from JSON file 📄 \\ 
            for tile in map_data:  # \\ Iterate over each tile in the map 🔲 \\ 
                x, y, tile_type = tile['x'], tile['y'], tile['tile_type']
                if tile_type == 'platform':  # \\ Create a platform 🟩 \\ 
                    platform = Platform(x * 40, y * 40, 40, 20)  # \\ Platforms are 40x20 tiles ⬛ \\ 
                    platforms.add(platform)
                elif tile_type == 'coin':  # \\ Create a coin 🪙 \\ 
                    coin = Coin(x * 40, y * 40)  # \\ Coins are 40x40 tiles 💵 \\ 
                    coins.add(coin)
                elif tile_type == 'door':  # \\ Create a door 🚪 \\ 
                    door = Door(x * 40, y * 40)  # \\ Door position based on map data 🏠 \\ 
    except FileNotFoundError:  # \\ If the map file is not found ❌ \\ 
        print(f"No custom map found. Loading default map.")  # \\ Print error message ❗ \\ 
    
    # \\ If no door was found, place one at a default location 📍 \\ 
    if door is None:
        door = Door(600, 500)  # \\ Default door position 🚪 \\ 

    return platforms, coins, door  # \\ Return created game objects 🛠️ \\

# --- Game Class --- 
class Game:
    def __init__(SELF):
        SELF.current_stage = 0  # \\ Start from stage 0 🎬 \\ 
        SELF.maps = [  # \\ List of map files 🗺️ \\ 
            "TestMap_2.json",
            "TestMap_4.json",
            "TestMap_3.json",
            "TestMap_5.json",
            "TestMap_6.json",
            "TestMap_8.json",
        ]
        SELF.player = Player()  # \\ Create the player 👤 \\ 
        SELF.key = Key(400, 500)  # \\ Create a key at position (400, 500) 🔑 \\

    def load_next_map(SELF):
        SELF.current_stage += 1  # \\ Move to the next stage ⏩ \\ 
        if SELF.current_stage >= len(SELF.maps):  # \\ If no more maps are available 🎮 \\ 
            print("You've completed all the stages! 🎉")  # \\ Print completion message 🎊 \\ 
            SELF.game_over()  # \\ End the game 🛑 \\ 
            return

        # \\ Load the new map 📂 \\ 
        map_filename = SELF.maps[SELF.current_stage]
        platforms, coins, door = load_map(map_filename)

        # \\ Reset player position and key 🔄 \\ 
        SELF.player.rect.center = (100, SCREEN_HEIGHT - 100)  # \\ Set the player to start position 🏃 \\ 
        SELF.player.has_key = False  # \\ Reset key possession 🔑❌ \\ 

        all_sprites = pygame.sprite.Group()  # \\ Create a group for all sprites 🖼️ \\ 
        all_sprites.add(SELF.player)  # \\ Add player to the sprite group 👤 \\ 
        all_sprites.add(SELF.key)  # \\ Add key to the sprite group 🔑 \\ 
        all_sprites.add(door)  # \\ Add door to the sprite group 🚪 \\ 
        all_sprites.add(platforms)  # \\ Add platforms to the sprite group 🪜 \\ 
        all_sprites.add(coins)  # \\ Add coins to the sprite group 💰 \\ 

        SELF.run_game(all_sprites, platforms, coins, door)  # \\ Run the game with the new map 🎮 \\ 

    def run_game(SELF, all_sprites, platforms, coins, door):
        clock = pygame.time.Clock()  # \\ Create a clock to control FPS 🕰️ \\ 
        score = 0  # \\ Initialize the score 💯 \\ 
        running = True  # \\ Game loop flag ⏳ \\ 
        while running:
            screen.fill(WHITE)  # \\ Clear the screen 🧼 \\ 
            for event in pygame.event.get():  # \\ Check for events 📝 \\ 
                if event.type == pygame.QUIT:  # \\ If the window is closed ❌ \\ 
                    running = False  # \\ Stop the game loop 🛑 \\ 
            keys = pygame.key.get_pressed()  # \\ Get the current key presses ⌨️ \\ 
            all_sprites.update(keys, platforms, SELF.key, door)  # \\ Update all sprites 🔄 \\ 
            coins_hit = pygame.sprite.spritecollide(SELF.player, coins, True)  # \\ Check for coin collection 💰✨ \\ 
            for coin in coins_hit:
                score += 1  # \\ Increase score for each collected coin 🏅 \\ 
            all_sprites.draw(screen)  # \\ Draw all sprites to the screen 🖌️ \\ 
            font = pygame.font.SysFont(None, 30)  # \\ Create a font for score display 📚 \\ 
            score_text = font.render(f"Score: {score}", True, RED)  # \\ Create a score text surface 🔴 \\ 
            screen.blit(score_text, (10, 10))  # \\ Draw the score to the screen 📊 \\ 
            pygame.display.flip()  # \\ Update the screen 🔄 \\ 
            clock.tick(FPS)  # \\ Control the FPS ⏱️ \\

    def start_menu(SELF):
        # \\ Start menu where the player can press a key to start the game 🎮 \\ 
        font = pygame.font.SysFont(None, 60)  # \\ Create a font for the title 🖋️ \\ 
        title_text = font.render("Press Any Key to Start", True, BLUE)  # \\ Create the title text 🖋️ \\ 
        screen.fill(WHITE)  # \\ Fill the screen with white ⚪ \\ 
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, SCREEN_HEIGHT // 2))  # \\ Draw the title in the center 🎯 \\ 
        pygame.display.flip()  # \\ Update the screen 🔄 \\

        waiting = True  # \\ Flag for waiting state 🕰️ \\ 
        while waiting:
            for event in pygame.event.get():  # \\ Check for events 📝 \\ 
                if event.type == pygame.QUIT:  # \\ If the window is closed ❌ \\ 
                    pygame.quit()  # \\ Quit pygame ❌ \\ 
                    exit()  # \\ Exit the program 🚪 \\ 
                if event.type == pygame.KEYDOWN:  # \\ If any key is pressed ⌨️ \\ 
                    waiting = False  # \\ Exit the waiting loop 🚪 \\ 

    def game_over(SELF):
        # \\ Game over screen, offering restart or quit 🕹️❌ \\ 
        font = pygame.font.SysFont(None, 30)  # \\ Create a font for the game over text 📚 \\ 
        game_over_text = font.render("Game Over! Press 'R' to Restart or 'Q' to Quit", True, RED)  # \\ Create the game over text 🔴 \\ 
        screen.fill(WHITE)  # \\ Fill the screen with white ⚪ \\ 
        screen.blit(game_over_text, (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, SCREEN_HEIGHT // 2))  # \\ Draw the text in the center 🎯 \\ 
        pygame.display.flip()  # \\ Update the screen 🔄 \\

        waiting = True  # \\ Flag for waiting for input ⏳ \\ 
        while waiting:
            for event in pygame.event.get():  # \\ Check for events 📝 \\ 
                if event.type == pygame.QUIT:  # \\ If the window is closed ❌ \\ 
                    pygame.quit()  # \\ Quit pygame ❌ \\ 
                    exit()  # \\ Exit the program 🚪 \\ 
                if event.type == pygame.KEYDOWN:  # \\ If a key is pressed ⌨️ \\ 
                    if event.key == pygame.K_q:  # \\ Quit the game if 'Q' is pressed ❌ \\ 
                        pygame.quit()  # \\ Quit pygame ❌ \\ 
                        exit()  # \\ Exit the program 🚪 \\ 
                    if event.key == pygame.K_r:  # \\ Restart the game if 'R' is pressed 🔁 \\ 
                        SELF.start_menu()  # \\ Restart the game 🏁 \\ 

# --- Main Function --- 
if __name__ == "__main__":
    game = Game()  # \\ Initialize the game 🕹️ \\ 
    game.start_menu()  # \\ Show the start menu 📜 \\ 
    game.load_next_map()  # \\ Load the first map 🔄 \\ 
