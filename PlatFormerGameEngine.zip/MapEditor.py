# \\ Import necessary libraries \\ 
import pygame  # \\ Pygame for game development and tile handling \\ 
import json  # \\ JSON for saving and loading map data \\ 
import sys  # \\ System functions for handling application exit \\ 
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QFileDialog, QMenuBar, QMenu, QAction, QLabel  # \\ PyQt5 for creating GUI elements and window \\ 
from PyQt5.QtCore import QTimer, Qt  # \\ PyQt5 core functionality for event handling and timer \\ 
from PyQt5.QtGui import QPainter, QImage, QColor, QPalette  # \\ PyQt5 for drawing and coloring \\ 
from Game_Colors import WHITE, RED, BLACK, BLUE, YELLOW, NEON_GREEN, NEON_PINK  # \\ Custom color definitions \\ 

# \\ Define constants \\ 
SCREEN_WIDTH = 800  # \\ Screen width in pixels \\ 
SCREEN_HEIGHT = 600  # \\ Screen height in pixels \\ 
FPS = 60  # \\ Frames per second (game update rate) \\ 
GRID_SIZE = 40  # \\ Size of each grid cell \\ 
TILE_TYPES = ['empty', 'platform', 'coin', 'key', 'door']  # \\ List of tile types (including new 'key' and 'door') \\ 


# \\ Tile class to represent individual map tiles \\ 
class Tile(pygame.sprite.Sprite):
    def __init__(SELF, x, y, tile_type):
        super().__init__()  # \\ Initialize sprite class \\ 
        SELF.x = x  # \\ X position of the tile \\ 
        SELF.y = y  # \\ Y position of the tile \\ 
        SELF.tile_type = tile_type  # \\ Type of tile (e.g. platform, coin, etc.) \\ 
        SELF.image = pygame.Surface((GRID_SIZE, GRID_SIZE))  # \\ Create surface for the tile \\ 
        SELF.rect = SELF.image.get_rect()  # \\ Get rectangle for positioning \\ 
        SELF.rect.x = x * GRID_SIZE  # \\ Set the X position \\ 
        SELF.rect.y = y * GRID_SIZE  # \\ Set the Y position \\ 

        # \\ Set tile color based on type \\ 
        if SELF.tile_type == 'platform':
            SELF.image.fill(NEON_GREEN)  # \\ Green for platform \\ 
        elif SELF.tile_type == 'coin':
            SELF.image.fill(YELLOW)  # \\ Yellow for coin \\ 
        elif SELF.tile_type == 'key':
            SELF.image.fill(NEON_PINK)  # \\ Pink for key \\ 
        elif SELF.tile_type == 'door':
            SELF.image.fill(RED)  # \\ Red for door \\ 
        else:
            SELF.image.fill(WHITE)  # \\ Default to white for empty \\ 

    def update(SELF):
        pass  # \\ No updates needed for the tile \\ 


# \\ MapEditor class for managing and drawing the map \\ 
class MapEditor:
    def __init__(SELF):
        SELF.tiles = pygame.sprite.Group()  # \\ Group to store all the tiles \\ 
        SELF.grid = {}  # \\ Dictionary to store tile positions and types \\ 
        SELF.selected_tile = 'platform'  # \\ Default selected tile type \\ 
        SELF.grid_width = SCREEN_WIDTH // GRID_SIZE  # \\ Calculate number of columns \\ 
        SELF.grid_height = SCREEN_HEIGHT // GRID_SIZE  # \\ Calculate number of rows \\ 
        SELF.action_stack = []  # \\ Stack to track actions for undo functionality \\ 

    def draw_grid(SELF, screen):
        for x in range(SELF.grid_width):  # \\ Loop through each column \\ 
            for y in range(SELF.grid_height):  # \\ Loop through each row \\ 
                pygame.draw.rect(screen, BLUE, (x * GRID_SIZE, y * GRID_SIZE, GRID_SIZE, GRID_SIZE), 1)  # \\ Draw grid lines \\ 

    def place_tile(SELF, x, y):
        previous_tile_type = SELF.grid.get((x, y), 'empty')  # \\ Track previous tile type at position \\ 
        SELF.action_stack.append((x, y, previous_tile_type))  # \\ Record the action for undo \\ 

        # \\ Place or erase tile based on selected type \\ 
        if SELF.selected_tile == 'empty':  # \\ Erase tile if selected tile is 'empty' \\ 
            if (x, y) in SELF.grid:
                SELF.tiles = pygame.sprite.Group([tile for tile in SELF.tiles if not (tile.x == x and tile.y == y)])  # \\ Remove tile from group \\ 
                del SELF.grid[(x, y)]  # \\ Remove tile from grid \\ 
        else:  # \\ Place new tile \\ 
            if (x, y) not in SELF.grid or SELF.grid[(x, y)] != SELF.selected_tile:  # \\ Check if the tile is different from existing \\ 
                tile = Tile(x, y, SELF.selected_tile)  # \\ Create new tile \\ 
                SELF.tiles.add(tile)  # \\ Add tile to sprite group \\ 
                SELF.grid[(x, y)] = SELF.selected_tile  # \\ Add tile to grid dictionary \\ 

    def undo(SELF):
        if SELF.action_stack:  # \\ If there are actions to undo \\ 
            x, y, previous_tile_type = SELF.action_stack.pop()  # \\ Get last action \\ 
            # \\ Revert to the previous tile type \\ 
            if previous_tile_type == 'empty':  # \\ If previous tile was empty, erase it \\ 
                if (x, y) in SELF.grid:
                    SELF.tiles = pygame.sprite.Group([tile for tile in SELF.tiles if not (tile.x == x and tile.y == y)])  # \\ Remove tile \\ 
                    del SELF.grid[(x, y)]  # \\ Remove tile from grid \\ 
            else:  # \\ Otherwise, restore the previous tile \\ 
                if (x, y) in SELF.grid:
                    SELF.tiles = pygame.sprite.Group([tile for tile in SELF.tiles if not (tile.x == x and tile.y == y)])  # \\ Remove tile \\ 
                tile = Tile(x, y, previous_tile_type)  # \\ Recreate the previous tile \\ 
                SELF.tiles.add(tile)  # \\ Add restored tile to group \\ 
                SELF.grid[(x, y)] = previous_tile_type  # \\ Restore tile in grid \\ 

    def save_map(SELF, filename):
        map_data = [{'x': x, 'y': y, 'tile_type': tile_type} for (x, y), tile_type in SELF.grid.items()]  # \\ Prepare map data for saving \\ 
        with open(filename, "w") as f:
            json.dump(map_data, f)  # \\ Save map data as JSON \\ 

    def load_map(SELF, filename):
        try:
            with open(filename, "r") as f:
                map_data = json.load(f)  # \\ Load map data from JSON \\ 
            SELF.tiles.empty()  # \\ Clear existing tiles \\ 
            SELF.grid.clear()  # \\ Clear grid \\ 
            for tile_data in map_data:  # \\ Loop through loaded tile data \\ 
                x, y, tile_type = tile_data['x'], tile_data['y'], tile_data['tile_type']  # \\ Extract tile info \\ 
                tile = Tile(x, y, tile_type)  # \\ Create new tile \\ 
                SELF.tiles.add(tile)  # \\ Add tile to sprite group \\ 
                SELF.grid[(x, y)] = tile_type  # \\ Add tile to grid \\ 
        except FileNotFoundError:  # \\ Handle error if map file doesn't exist \\ 
            print("No map found to load.")  # \\ Print error message \\ 


# \\ PygameWidget class to integrate Pygame surface into PyQt5 GUI \\ 
class PygameWidget(QWidget):
    def __init__(SELF, parent=None):
        super().__init__(parent)  # \\ Initialize QWidget \\ 
        SELF.editor = MapEditor()  # \\ Initialize the map editor \\ 
        SELF.surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))  # \\ Create a Pygame surface \\ 
        SELF.setMinimumSize(SCREEN_WIDTH, SCREEN_HEIGHT)  # \\ Set widget size \\ 
        SELF.timer = QTimer(SELF)  # \\ Set up a timer for periodic updates \\ 
        SELF.timer.timeout.connect(SELF.update_pygame)  # \\ Connect the timer to update function \\ 
        SELF.timer.start(1000 // FPS)  # \\ Start timer with frame rate \\ 

    def paintEvent(SELF, event):
        painter = QPainter(SELF)  # \\ Create QPainter to paint Pygame surface \\ 
        image = pygame.image.tostring(SELF.surface, "RGB")  # \\ Convert Pygame surface to string \\ 
        qimage = QImage(image, SCREEN_WIDTH, SCREEN_HEIGHT, QImage.Format_RGB888)  # \\ Convert to QImage \\ 
        painter.drawImage(0, 0, qimage)  # \\ Draw image onto widget \\ 

    def update_pygame(SELF):
        SELF.surface.fill(BLACK)  # \\ Clear the Pygame surface \\ 
        SELF.editor.draw_grid(SELF.surface)  # \\ Draw the grid \\ 
        SELF.editor.tiles.draw(SELF.surface)  # \\ Draw the tiles \\ 
        SELF.update()  # \\ Trigger update to repaint \\ 

    def mousePressEvent(SELF, event):
        if event.button() == Qt.LeftButton:  # \\ If left mouse button is clicked \\ 
            grid_x = event.x() // GRID_SIZE  # \\ Calculate grid position based on click \\ 
            grid_y = event.y() // GRID_SIZE  # \\ Calculate grid position \\ 
            SELF.editor.place_tile(grid_x, grid_y)  # \\ Place tile at the grid position \\ 


# \\ MainWindow class for PyQt5 GUI setup and menu handling \\ 
class MainWindow(QMainWindow):
    def __init__(SELF):
        super().__init__()  # \\ Initialize QMainWindow \\ 
        SELF.setWindowTitle("Neon Map Editor")  # \\ Set window title \\ 
        SELF.setGeometry(100, 100, SCREEN_WIDTH, SCREEN_HEIGHT)  # \\ Set window geometry \\ 

        # \\ Set up central widget and layout \\ 
        SELF.central_widget = QWidget()  # \\ Create central widget \\ 
        SELF.setCentralWidget(SELF.central_widget)  # \\ Set central widget \\ 
        SELF.main_layout = QVBoxLayout(SELF.central_widget)  # \\ Create main layout \\ 

        # \\ Add the Pygame widget to layout \\ 
        SELF.pygame_widget = PygameWidget(SELF)  # \\ Create Pygame widget \\ 
        SELF.main_layout.addWidget(SELF.pygame_widget)  # \\ Add widget to layout \\ 

        # \\ Add menu bar for file and tile actions \\ 
        SELF.menu_bar = QMenuBar(SELF)  # \\ Create menu bar \\ 
        SELF.setMenuBar(SELF.menu_bar)  # \\ Set menu bar \\ 
        SELF.setup_menus()  # \\ Set up the menus \\ 

        # \\ Add a status bar for feedback \\ 
        SELF.status_bar = SELF.statusBar()  # \\ Create status bar \\ 
        SELF.status_bar.setStyleSheet("background-color: rgb(30, 30, 30); color: white;")  # \\ Style status bar \\ 
        SELF.status_bar.showMessage("Platform Map Maker")  # \\ Display initial message \\ 

    def setup_menus(SELF):
        """Set up the menu bar with all options."""  
        # \\ File menu \\ 
        file_menu = QMenu("File", SELF)  # \\ Create file menu \\ 
        SELF.menu_bar.addMenu(file_menu)  # \\ Add to menu bar \\ 

        save_action = QAction("Save Map", SELF)  # \\ Create save action \\ 
        save_action.triggered.connect(SELF.save_map)  # \\ Connect save action \\ 
        file_menu.addAction(save_action)  # \\ Add action to menu \\ 

        load_action = QAction("Load Map", SELF)  # \\ Create load action \\ 
        load_action.triggered.connect(SELF.load_map)  # \\ Connect load action \\ 
        file_menu.addAction(load_action)  # \\ Add action to menu \\ 

        exit_action = QAction("Exit", SELF)  # \\ Create exit action \\ 
        exit_action.triggered.connect(SELF.close)  # \\ Connect exit action \\ 
        file_menu.addAction(exit_action)  # \\ Add action to menu \\ 

        # \\ Edit menu \\ 
        edit_menu = QMenu("Edit", SELF)  # \\ Create edit menu \\ 
        SELF.menu_bar.addMenu(edit_menu)  # \\ Add to menu bar \\ 

        undo_action = QAction("Undo", SELF)  # \\ Create undo action \\ 
        undo_action.triggered.connect(SELF.undo_last_action)  # \\ Connect undo action \\ 
        edit_menu.addAction(undo_action)  # \\ Add action to menu \\ 

        # \\ Tile selection menu \\ 
        tile_menu = QMenu("Tiles", SELF)  # \\ Create tiles menu \\ 
        SELF.menu_bar.addMenu(tile_menu)  # \\ Add to menu bar \\ 

        platform_action = QAction("Platform Tile", SELF)  # \\ Create platform tile action \\ 
        platform_action.triggered.connect(lambda: SELF.set_selected_tile('platform'))  # \\ Select platform tile \\ 
        tile_menu.addAction(platform_action)  # \\ Add action to menu \\ 

        coin_action = QAction("Coin Tile", SELF)  # \\ Create coin tile action \\ 
        coin_action.triggered.connect(lambda: SELF.set_selected_tile('coin'))  # \\ Select coin tile \\ 
        tile_menu.addAction(coin_action)  # \\ Add action to menu \\ 

        key_action = QAction("Key Tile", SELF)  # \\ Create key tile action \\ 
        key_action.triggered.connect(lambda: SELF.set_selected_tile('key'))  # \\ Select key tile \\ 
        tile_menu.addAction(key_action)  # \\ Add action to menu \\ 

        door_action = QAction("Door Tile", SELF)  # \\ Create door tile action \\ 
        door_action.triggered.connect(lambda: SELF.set_selected_tile('door'))  # \\ Select door tile \\ 
        tile_menu.addAction(door_action)  # \\ Add action to menu \\ 

        empty_action = QAction("Empty Tile", SELF)  # \\ Create empty tile action \\ 
        empty_action.triggered.connect(lambda: SELF.set_selected_tile('empty'))  # \\ Select empty tile \\ 
        tile_menu.addAction(empty_action)  # \\ Add action to menu \\ 

    def save_map(SELF):
        options = QFileDialog.Options()  # \\ Set up file dialog options \\ 
        filename, _ = QFileDialog.getSaveFileName(SELF, "Save Map", "", "JSON Files (*.json)", options=options)  # \\ Open file save dialog \\ 
        if filename:  # \\ If filename is selected \\ 
            SELF.pygame_widget.editor.save_map(filename)  # \\ Save map \\ 
            SELF.status_bar.showMessage(f"Map saved to {filename}")  # \\ Display success message \\ 

    def load_map(SELF):
        options = QFileDialog.Options()  # \\ Set up file dialog options \\ 
        filename, _ = QFileDialog.getOpenFileName(SELF, "Load Map", "", "JSON Files (*.json)", options=options)  # \\ Open file open dialog \\ 
        if filename:  # \\ If filename is selected \\ 
            SELF.pygame_widget.editor.load_map(filename)  # \\ Load map \\ 
            SELF.status_bar.showMessage(f"Map loaded from {filename}")  # \\ Display success message \\ 

    def set_selected_tile(SELF, tile_type):
        SELF.pygame_widget.editor.selected_tile = tile_type  # \\ Set selected tile type \\ 
        SELF.status_bar.showMessage(f"Selected tile type: {tile_type}")  # \\ Show selected tile in status bar \\ 

    def undo_last_action(SELF):
        SELF.pygame_widget.editor.undo()  # \\ Undo last action \\ 
        SELF.status_bar.showMessage("Last action undone.")  # \\ Show undo message \\ 


# \\ Main entry point to run the application \\ 
if __name__ == "__main__":
    pygame.init()  # \\ Initialize Pygame \\ 
    app = QApplication(sys.argv)  # \\ Initialize PyQt application \\ 
    app.setStyle("Fusion")  # \\ Set Fusion style for the GUI \\ 
    
    # \\ Set neon color theme for the application \\ 
    palette = QPalette()  # \\ Create color palette \\ 
    palette.setColor(QPalette.Window, QColor(20, 20, 20))  # \\ Set window color \\ 
    palette.setColor(QPalette.WindowText, QColor(255, 255, 255))  # \\ Set text color \\ 
    palette.setColor(QPalette.Button, QColor(30, 30, 30))  # \\ Set button color \\ 
    palette.setColor(QPalette.ButtonText, QColor(255, 255, 255))  # \\ Set button text color \\ 
    app.setPalette(palette)  # \\ Apply palette to application \\

    window = MainWindow()  # \\ Create main window \\ 
    window.show()  # \\ Show window \\ 
    sys.exit(app.exec_())  # \\ Start the PyQt application event loop \\ 
